self.__precacheManifest = [
  {
    "revision": "06e5e022028ab630b0c7653717e4000f",
    "url": "/static/media/home.06e5e022.png"
  },
  {
    "revision": "14518fd32702a0a9311ebfa98dde17d1",
    "url": "/static/media/footer-icon.14518fd3.png"
  },
  {
    "revision": "a69c617ac601aa5d507165ff519f7438",
    "url": "/static/media/content-icon.a69c617a.png"
  },
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "d4047729a59933014dde",
    "url": "/static/js/main.d4047729.chunk.js"
  },
  {
    "revision": "6bd1887f93820a1d3194",
    "url": "/static/js/2.6bd1887f.chunk.js"
  },
  {
    "revision": "d4047729a59933014dde",
    "url": "/static/css/main.0463265c.chunk.css"
  },
  {
    "revision": "0246956fe5b0553cc0392158c48841dd",
    "url": "/index.html"
  }
];